#ifndef _BARCODE_H
#define _BARCODE_H

#include <stddef.h>
#define TABLE_SIZE 100

// Define the structure for key-value pairs.
struct KeyValuePair {
    char* key;
    char* value;
    struct KeyValuePair* next;
};

// Define the hash map as an array of pointers to KeyValuePair.
struct KeyValuePair* myHashMap[TABLE_SIZE] = {NULL};

unsigned int hashFunction(const char* key);
void insertKeyValuePair(const char* key, const char* value);
void init_hashmap(__unused void *params);
const char* getValue(const char *key);

#endif