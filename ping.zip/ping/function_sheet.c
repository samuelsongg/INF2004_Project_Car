/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pwm.h"
#include "hardware/gpio.h"
#include "hardware/adc.h"

// Function to set the state of a GPIO permanently.
void setGPIO(int pin, int state)
{
    gpio_init(pin); // Initialise GPIO.
    gpio_set_dir(pin, GPIO_OUT); // Set GPIO direction to output.
    gpio_put(pin, state); // Set GPIO pin to high (1) or low (0).
}

// Function to set the GPIO to act as a push down button (normal button).
// When no press, GPIO is low. When pressed, GPIO is high.
void setGPIOPushDown(int pin)
{
    gpio_init(pin); // Initialise GPIO.
    gpio_set_dir(pin, GPIO_IN); // Set GPIO direction to input.
    gpio_set_pulls(pin, false, true); // Set GPIO pin to push down.
}

// Function to set the GPIO to act as a pull up button.
// When no press, GPIO is high. When pressed, GPIO is low.
void setGPIOPullUp(int pin)
{
    gpio_init(pin); // Initialise GPIO.
    gpio_set_dir(pin, GPIO_IN); // Set GPIO direction to input.
    gpio_set_pulls(pin, true, false); // Set GPIO pin to pull up.
}

// Function to set the state of a PWM pin.
void setPWM(int pwm_pin)
{
    gpio_set_function(pwm_pin, GPIO_FUNC_PWM); // Allocate GPIO to function as PWM.
    uint slice_num = pwm_gpio_to_slice_num(pwm_pin); // Get the slice number from the GPIO pin.
    pwm_set_clkdiv(slice_num, 100); // Set the clock divider; reduce main clock to 1.25MHz (1,250,000) from 125MHz.
    pwm_set_wrap(slice_num, 62500); // Set the period to 62500 cycles; 1,250,000 (1.25MHz) / 62500 = 20Hz.
    pwm_set_chan_level(slice_num, PWM_CHAN_A, 62500 * 0.5); // Set the duty cycle to 50%.
    pwm_set_enabled(slice_num, true); // Enable PWM.
}

// Function to create a periodic timer.
struct repeating_timer timer;
bool timer_callback(struct repeating_timer *t)
{
    static int count = 0; // Static so that count will not reset on each call.
    count++;
    printf("Hello, world! Count = %d\n", count);
    return true;
}
//cancel_repeating_timer(&timer);

// Function to create a single-shot timer.
volatile bool timer_fired = false;
int64_t alarm_callback(alarm_id_t id, void *user_data)
{
    printf("Single-shot timer %d fired!\n", id);
    timer_fired = true;
    return 0;
}


// Measure time difference between two events.
void measureTime()
{
    absolute_time_t start_time = get_absolute_time();
    // Do something here.
    absolute_time_t end_time = get_absolute_time();
    uint64_t elapsed_time = absolute_time_diff_us(start_time, end_time);
    printf("Elapsed time = %lld\n", elapsed_time);
}

// Function to create an interrupt.
void gpio_callback(uint gpio, uint32_t events)
{
    printf("GPIO %d interrupt\n", gpio);
}

int main()
{
    stdio_init_all();  

    // Create a repeating timer to call timer_callback() every 1000ms.
    add_repeating_timer_ms(1000, timer_callback, NULL, &timer);
    // Cancel timer.
    cancel_repeating_timer(&timer);

    // Create a single-shot timer.
    add_alarm_in_ms(5000, alarm_callback, NULL, false);

    // Create an interrupt.
    gpio_set_irq_enabled_with_callback(20, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &gpio_callback);

    while (1) {
        tight_loop_contents();
    }
}

/*** end of file ***/