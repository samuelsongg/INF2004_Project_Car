/**
 * Copyright (c) 2022 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdio.h>

#include "pico/cyw43_arch.h"
#include "pico/stdlib.h"

#include "lwip/ip4_addr.h"

#include "FreeRTOS.h"
#include "task.h"
#include "ping.h"
#include "message_buffer.h"

#include "hardware/gpio.h"
#include "hardware/adc.h"
#include "hardware/pwm.h"

#define mbaTASK_MESSAGE_BUFFER_SIZE       ( 60 )

#ifndef PING_ADDR
#define PING_ADDR "142.251.35.196"
#endif
#ifndef RUN_FREERTOS_ON_CORE
#define RUN_FREERTOS_ON_CORE 0
#endif

#define TEST_TASK_PRIORITY				( tskIDLE_PRIORITY + 1UL )

static MessageBufferHandle_t xControlMessageBuffer;

const uint RIGHT_WHEEL_FORWARD = 18;
const uint RIGHT_WHEEL_BACKWARD = 19;
const uint LEFT_WHEEL_FORWARD = 20;
const uint LEFT_WHEEL_BACKWARD = 21;
const uint IR_SENSOR = 4;

volatile char direction = 'w';

void move_wheels(__unused void *params) {
    gpio_set_function(14, GPIO_FUNC_PWM);
    gpio_set_function(15, GPIO_FUNC_PWM);

    uint slice_num14 = pwm_gpio_to_slice_num(14);
    uint slice_num15 = pwm_gpio_to_slice_num(15);

    pwm_set_clkdiv(slice_num14, 100);
    pwm_set_clkdiv(slice_num15, 100);
    
    pwm_set_wrap(slice_num14, 12500);
    pwm_set_wrap(slice_num15, 12500);
    
    pwm_set_chan_level(slice_num14, PWM_CHAN_A, 12500 / 2);
    pwm_set_chan_level(slice_num15, PWM_CHAN_B, 12500 / 2);
    
    pwm_set_enabled(slice_num14, true);
    pwm_set_enabled(slice_num15, true);

    gpio_init(RIGHT_WHEEL_FORWARD);
    gpio_init(RIGHT_WHEEL_BACKWARD);
    gpio_init(LEFT_WHEEL_FORWARD);
    gpio_init(LEFT_WHEEL_BACKWARD);

    gpio_set_dir(RIGHT_WHEEL_FORWARD, GPIO_OUT);
    gpio_set_dir(RIGHT_WHEEL_BACKWARD, GPIO_OUT);
    gpio_set_dir(LEFT_WHEEL_FORWARD, GPIO_OUT);
    gpio_set_dir(LEFT_WHEEL_BACKWARD, GPIO_OUT);

    while (true) {
        vTaskDelay(1000);
        gpio_put(RIGHT_WHEEL_FORWARD, 1);
        gpio_put(RIGHT_WHEEL_BACKWARD, 0);
        gpio_put(LEFT_WHEEL_FORWARD, 1);
        gpio_put(LEFT_WHEEL_BACKWARD, 0);    
    }
}

void get_direction(__unused void *params) {
    while (true) {
        char input_direction = getchar();

        if (input_direction == 'w') {
            direction = 'w';
            printf("Direction: %c\n", direction);
        }
        else if (input_direction == 's') {
            direction = 's';
            printf("Direction: %c\n", direction);
        }
    }
}

void printing(__unused void *params) {
    while (true) {
        //char input_direction = getchar();
        vTaskDelay(1000);
        printf("Testing");
        // Send a message buffer to the control task

    }
}

void __not_in_flash_func(adc_capture)(uint16_t *buf, size_t count) {
    adc_fifo_setup(true, false, 0, false, false);
    adc_run(true);
    for (int i = 0; i < count; i = i + 1)
        buf[i] = adc_fifo_get_blocking();
    adc_run(false);
    adc_fifo_drain();
}

void read_ir_sensor(__unused void *params) {
    gpio_set_function(IR_SENSOR, GPIO_FUNC_SIO);
    gpio_set_dir(IR_SENSOR, GPIO_IN); // IR Sensor

    adc_init();
    adc_set_temp_sensor_enabled(true);

    gpio_disable_pulls(IR_SENSOR);
    gpio_set_input_enabled(IR_SENSOR, false);

    while (true) {
        vTaskDelay(1000);
        uint32_t result = adc_read();        
        const float conversion_factor = 3.3f / (1 << 12);
        printf("\n0x%03x -> %f V\n", result, result * conversion_factor);
        printf("ADC Result: %d\n", result);
    }
}

void vLaunch( void) {
    // TaskHandle_t getDirectionTask;
    // xTaskCreate(get_direction, "GetDirectionThread", configMINIMAL_STACK_SIZE, NULL, 9, &getDirectionTask);
    TaskHandle_t moveWheelsTask;
    xTaskCreate(move_wheels, "MoveWheelsThread", configMINIMAL_STACK_SIZE, NULL, 7, &moveWheelsTask);
    TaskHandle_t readIrSensorTask;
    xTaskCreate(read_ir_sensor, "ReadIrSensorThread", configMINIMAL_STACK_SIZE, NULL, 8, &readIrSensorTask);
    TaskHandle_t printTask;
    xTaskCreate(printing, "PrintThread", configMINIMAL_STACK_SIZE, NULL, 5, &printTask);

    xControlMessageBuffer = xMessageBufferCreate(mbaTASK_MESSAGE_BUFFER_SIZE);

#if NO_SYS && configUSE_CORE_AFFINITY && configNUM_CORES > 1
    // we must bind the main task to one core (well at least while the init is called)
    // (note we only do this in NO_SYS mode, because cyw43_arch_freertos
    // takes care of it otherwise)
    vTaskCoreAffinitySet(task, 1);
#endif

    /* Start the tasks and timer running. */
    vTaskStartScheduler();
}

int main( void )
{
    stdio_init_all();

    /* Configure the hardware ready to run the demo. */
    const char *rtos_name;
#if ( portSUPPORT_SMP == 1 )
    rtos_name = "FreeRTOS SMP";
#else
    rtos_name = "FreeRTOS";
#endif

#if ( portSUPPORT_SMP == 1 ) && ( configNUM_CORES == 2 )
    printf("Starting %s on both cores:\n", rtos_name);
    vLaunch();
#elif ( RUN_FREERTOS_ON_CORE == 1 )
    printf("Starting %s on core 1:\n", rtos_name);
    multicore_launch_core1(vLaunch);
    while (true);
#else
    printf("Starting %s on core 0:\n", rtos_name);
    vLaunch();
#endif
    return 0;
}

/*** end of file ***/